# Injective-Pay ---- WooCommerce Plugin

Use this plugin with the INJ token payment gateway

eCommerce Payment Gateway Usage (replace parameters with your own OR use our WooCommerce plugin)
https://injectivepay.netlify.app/?toAddress=0x398E83a2D88dB17F29cBB5EBae955aD46bbf1EbB&valueToSend=0.001&memo=Merchant ABC&merchanturl=https://abc.com&order_id=123

POS Usage  (replace toAddress with your Injective EVM wallet address)
https://injectivepay.netlify.app/pos.html?toAddress=0x398E83a2D88dB17F29cBB5EBae955aD46bbf1EbB

Project uses inEVM devnet https://calderaxyz.gitbook.io/injective-documentation/getting-started/add-inevm-to-metamask

Hackathon submission for Injective x Google Cloud Illuminate Hackathon
https://dorahacks.io/hackathon/illuminate/buidl
